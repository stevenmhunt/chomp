# Everything You Need to Know About Rocket Fins

The fins on a model rocket are considered one of the most important parts of a rocket’s structure and can determine whether a rocket flies properly or crashes to the ground. While fins vary widely in size and shape depending on the rocket they’re attached to, they are almost always present.

### Whether you're a student learning about rocketry
### Or
### A rocket scientist...

You'll need to understand the basic concepts of why rocket fins are employed and how they aid in rocket flight.

### So, let's dive in!
