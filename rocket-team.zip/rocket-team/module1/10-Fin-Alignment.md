# Proper Fin Alignment and Attachment

A model rocket needs to have at least three fins in order to maintain a stable vertical position, but some model rockets are designed with four fins instead of three.

Four is the most fins you will see on most model rockets, as any more fins would only increase the weight of a rocket and potentially destabilize it.

Having four fins on a rocket provides more stability over three since it provides equal support from four corners that are equal distances apart (90 degrees), but it also increases the drag and air resistance of a rocket due to the increase in weight.

So at the end of the day, making the decision between using 3 or 4 fins for your rocket design is an art of balancing between stability and drag.

### Now that we got that out of the way, let's get our hands dirty!
