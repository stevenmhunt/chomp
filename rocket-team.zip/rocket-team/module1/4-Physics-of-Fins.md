# The Physics of Rocket Fins

In simplest terms, an object’s center of gravity is the point within the object at the center of its mass and is related to an object’s balancing weight. 

So, the center of gravity is in direct relation to an object’s weight.

For example, in a person, the center of gravity is slightly higher than a person’s waist because a person’s upper half is typically heavier than their bottom half. Likewise, a rocket with a nose cone and forward body that are heavier than its aft end will have a high center of gravity. 

A model rocket’s center of gravity is the point on which the rocket is perfectly balanced, tipping neither forward nor backward. 

Relative to a fin’s center of gravity, the model rocket’s center of pressure refers to the point at which all the aerodynamic forces act on the rocket.

Once the center of pressure is determined, rocket design dictates that the center of pressure must be aft (rearward) of the rocket’s center of gravity in order for the rocket to have a stable flight without tumbling.

This is where the model rocket’s fins come into play. 

The rocket’s fins create a center of pressure on the rocket that is aft (rearward) of its center of gravity. That way when the rocket launches, it will launch straight up and down. 


