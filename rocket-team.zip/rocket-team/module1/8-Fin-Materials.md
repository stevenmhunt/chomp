# Rocket Fin Materials

Model rocket fins can also be constructed from a variety of different materials.

Furthermore, with the advancements of 3D printing technologies, some people who design model rockets have begun to use more sophisticated materials, such as lightweight polymers, that can be 3D printed using a CAD design.

But, for those who are just starting out and want to keep it simple, here are a few of the more common materials that people often use to design a model rocket. 
