### Fins add the necessary stability to a rocket
