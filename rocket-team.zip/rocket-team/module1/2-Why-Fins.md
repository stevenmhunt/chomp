# Why do we even need fins in the first place?

Fins are important because they help keep the rocket stable during flight. The stability of a rocket is determined by the locations of the center of gravity (CG) and center of pressure (CP), which must be located behind the CG. The rocket is more stable when the CG and CP are further apart. The fins help increase the stability by moving the center of pressure towards the aft of the rocket. Fins that are not properly aligned will induce a moment that may affect the rotation of the rocket, causing the rocket to veer off its intended path.
