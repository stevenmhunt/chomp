# Rocket Fin Shapes

Model rocket fins come in a few different shapes, also known as planforms.

**Different shapes of model rocket fins offer different advantages and disadvantages.**

A tapered swept tip fin shape could help keep a rocket lightweight in design, but it offers less stability than a clipped delta fin. Similarly, a trapezoidal fin may be a good choice for mid-sized rockets but might prove to be too bulky for smaller models. 
