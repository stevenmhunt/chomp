### Fins move the center of pressure to the tail of a rocket
### =
### More stability!
