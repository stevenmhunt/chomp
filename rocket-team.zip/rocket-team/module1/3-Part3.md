### Improper fin alignment can lead to unexpected results
